# Radar MindMap Assistant — Python Monorepo (v1)

This repo is a **single-language Python** build that mirrors the Android/Web stack:
- **FastAPI** backend with routes for exports, timesheets, WHIP (WebRTC ingest), and health.
- **Export engines**: DOCX, PDF, PPTX (Slides-like), XLSX, Markdown.
- **Overlay & tile cache** skeletons (OpenCV + disk cache).
- **PWA**: manifest + service worker for offline + background upload.
- **Google integrations** stubs (Docs/Slides/Drive) using `google-api-python-client`.
- **WHIP** endpoint scaffold via `aiortc` (low-latency RTSP→WebRTC bridge target).

> It ships runnable defaults with local storage. Cloud bits (GCS/Google OAuth) are opt-in via `.env`.

## Quick start

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Dev run
uvicorn app.main:app --reload --port 8080
```

Open: http://localhost:8080

## Deploy (Docker)
```bash
docker build -t radar-mindmap-python:v1 .
docker run -p 8080:8080 --env-file .env radar-mindmap-python:v1
```

## Structure
```
app/
  main.py                # FastAPI app + static & templates
  routers/
    health.py
    export.py
    timesheet.py
    whip.py
  services/
    storage.py           # Local or GCS
    export_service.py    # DOCX/PDF/PPTX/XLSX/MD generators
    tile_cache.py        # Map tile cache (disk LRU)
    overlay.py           # OpenCV stamp compositor
    rtsp_recorder.py     # ffmpeg-based ingest/segmenter (skeleton)
  models/                # Pydantic models
  static/                # PWA assets (manifest, sw.js, icons)
  templates/             # Jinja pages (PWA shell)
scripts/
  run_server.sh
tests/
  test_health.py
```

## Notes
- **WHIP**: included minimal SDP offer/answer via `aiortc`. For production, front with MediaMTX or mediasoup. 
- **Google Docs/Slides**: stubs wired; add your OAuth creds and uncomment the calls in the exporter.
- **Tile cache**: HTTP fetch + on-disk cache for overlay mini-map; add your provider and key if required.
