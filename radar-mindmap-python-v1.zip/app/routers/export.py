from fastapi import APIRouter, BackgroundTasks
from pydantic import BaseModel, Field
from typing import Literal, Dict, Any
from ..services import export_service

router = APIRouter()

class ExportRequest(BaseModel):
    kind: Literal["docx","pdf","pptx","xlsx","md"]
    title: str = Field(..., min_length=1)
    content: str | Dict[str, Any] = Field(default_factory=dict)

class ExportResponse(BaseModel):
    url: str

@router.post("/{kind}", response_model=ExportResponse)
async def create_export(kind: str, req: ExportRequest, tasks: BackgroundTasks):
    kind = kind.lower()
    if kind == "docx":
        url = export_service.export_docx(req.title, req.content)
    elif kind == "pdf":
        url = export_service.export_pdf(req.title, req.content)
    elif kind == "pptx":
        url = export_service.export_pptx(req.title, req.content)
    elif kind == "xlsx":
        url = export_service.export_xlsx(req.title, req.content if isinstance(req.content, list) else [])
    elif kind == "md":
        url = export_service.export_md(req.title, req.content)
    else:
        raise ValueError("Unsupported kind")
    return ExportResponse(url=url)
