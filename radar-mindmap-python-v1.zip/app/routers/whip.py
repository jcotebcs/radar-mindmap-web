from fastapi import APIRouter, Request, Response
from aiortc import RTCPeerConnection
import asyncio, json

router = APIRouter()

@router.post("")
async def whip_offer(request: Request):
    offer_sdp = await request.body()
    pc = RTCPeerConnection()
    # NOTE: For brevity, we don't wire actual media tracks here.
    await pc.setRemoteDescription({"type": "offer", "sdp": offer_sdp.decode()})
    answer = await pc.createAnswer()
    await pc.setLocalDescription(answer)
    # Cleanup in background
    asyncio.create_task(_cleanup(pc))
    return Response(content=pc.localDescription.sdp, media_type="application/sdp")

async def _cleanup(pc: RTCPeerConnection):
    await asyncio.sleep(60)
    await pc.close()
