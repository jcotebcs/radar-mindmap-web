from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import time, uuid

DB: Dict[str, Dict[str, Any]] = {}

router = APIRouter()

class StartReq(BaseModel):
    user_id: str
    project: str
    notes: Optional[str] = None
    billable: bool = True
    rate_per_hour: Optional[float] = None

class StopReq(BaseModel):
    id: str

@router.post("/start")
def start(req: StartReq):
    entry_id = uuid.uuid4().hex[:12]
    DB[entry_id] = {
        "id": entry_id,
        "user_id": req.user_id,
        "project": req.project,
        "start_ts": int(time.time()),
        "end_ts": None,
        "notes": req.notes,
        "billable": req.billable,
        "rate_per_hour": req.rate_per_hour,
    }
    return DB[entry_id]

@router.post("/stop")
def stop(req: StopReq):
    if req.id not in DB: 
        return {"error":"not_found"}
    DB[req.id]["end_ts"] = int(time.time())
    return DB[req.id]

@router.get("/list")
def list_entries():
    return list(DB.values())
