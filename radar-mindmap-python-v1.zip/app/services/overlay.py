from typing import Optional, Tuple
from PIL import Image, ImageDraw, ImageFont
import io, math
from . import tile_cache

# Simple GPS/alt/heading stamp + mini tile inset
def render_overlay(width:int, height:int, lat:float, lon:float, alt_m:float|None, heading_deg:float|None) -> bytes:
    # Base transparent image
    img = Image.new("RGBA", (width, height), (0,0,0,0))
    draw = ImageDraw.Draw(img)
    font = ImageFont.load_default()

    # Text block
    text = f"Lat {lat:.6f}, Lon {lon:.6f}"
    if alt_m is not None: text += f" | Alt {alt_m:.1f} m"
    if heading_deg is not None: text += f" | Heading {heading_deg:.0f}°"
    draw.rectangle((8,8,8+360,8+40), fill=(0,0,0,128))
    draw.text((16,16), text, fill=(255,255,255,255), font=font)

    # Mini map inset (3x3 tiles at zoom 15, stitched)
    zoom = 15
    x, y = tile_cache.deg2num(lat, lon, zoom)
    tiles = []
    for dy in (-1,0,1):
        row = []
        for dx in (-1,0,1):
            data = tile_cache.fetch_tile(zoom, x+dx, y+dy)
            row.append(Image.open(io.BytesIO(data)))
        tiles.append(row)
    # Stitch
    tile_w, tile_h = tiles[0][0].size
    stitched = Image.new("RGB", (tile_w*3, tile_h*3))
    for j in range(3):
        for i in range(3):
            stitched.paste(tiles[j][i], (i*tile_w, j*tile_h))
    # Resize to inset
    inset = stitched.resize((180, 180))
    img.paste(inset, (width-196, 16))

    out = io.BytesIO()
    img.save(out, format="PNG")
    return out.getvalue()
