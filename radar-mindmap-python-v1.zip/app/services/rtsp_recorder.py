import subprocess, shlex, time, os, signal, threading
from pathlib import Path
from typing import Optional

FFMPEG = os.getenv("FFMPEG_BIN", "ffmpeg")

def record_rtsp_to_mp4(rtsp_url: str, out_path: str, segment_seconds: int = 0) -> subprocess.Popen:
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    if segment_seconds > 0:
        cmd = f"""{FFMPEG} -hide_banner -loglevel warning -rtsp_transport tcp -i "{rtsp_url}"  -c copy -f segment -segment_time {segment_seconds} -reset_timestamps 1 "{out_path}""""
    else:
        cmd = f"""{FFMPEG} -hide_banner -loglevel warning -rtsp_transport tcp -i "{rtsp_url}"  -c copy -movflags +faststart "{out_path}""""
    return subprocess.Popen(shlex.split(cmd))

def stop_recording(proc: subprocess.Popen, timeout=5):
    if proc.poll() is None:
        proc.send_signal(signal.SIGINT)
        try:
            proc.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            proc.kill()
