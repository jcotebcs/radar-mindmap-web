import io, time, uuid, json
from typing import Dict, Any
from . import storage

# DOCX
from docx import Document
# PPTX
from pptx import Presentation
from pptx.util import Inches, Pt
# PDF
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas
# XLSX
from openpyxl import Workbook
# MD
import markdown

def _job_id() -> str:
    return uuid.uuid4().hex[:12]

def export_docx(title: str, content: str | Dict[str, Any]) -> str:
    doc = Document()
    doc.add_heading(title, 0)
    if isinstance(content, dict):
        content = json.dumps(content, indent=2)
    for line in str(content).splitlines():
        doc.add_paragraph(line)
    buf = io.BytesIO()
    doc.save(buf)
    path = f"exports/{int(time.time())}-{_job_id()}.docx"
    return storage.save_bytes(path, buf.getvalue())

def export_pptx(title: str, content: str | Dict[str, Any]) -> str:
    prs = Presentation()
    slide_layout = prs.slide_layouts[1]  # Title and Content
    slide = prs.slides.add_slide(slide_layout)
    slide.shapes.title.text = title
    body = slide.placeholders[1].text_frame
    if isinstance(content, dict):
        content = json.dumps(content, indent=2)
    for line in str(content).splitlines():
        p = body.add_paragraph()
        p.text = line
        p.font.size = Pt(14)
    buf = io.BytesIO()
    prs.save(buf)
    path = f"exports/{int(time.time())}-{_job_id()}.pptx"
    return storage.save_bytes(path, buf.getvalue())

def export_pdf(title: str, content: str | Dict[str, Any]) -> str:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=LETTER)
    width, height = LETTER
    c.setFont("Helvetica-Bold", 16)
    c.drawString(72, height-72, title)
    c.setFont("Helvetica", 11)
    y = height-100
    if isinstance(content, dict):
        content = json.dumps(content, indent=2)
    for line in str(content).splitlines():
        if y < 72:
            c.showPage(); y = height-72
        c.drawString(72, y, line[:110])
        y -= 14
    c.showPage()
    c.save()
    path = f"exports/{int(time.time())}-{_job_id()}.pdf"
    return storage.save_bytes(path, buf.getvalue())

def export_xlsx(title: str, rows: Dict[str, Any] | list) -> str:
    wb = Workbook()
    ws = wb.active
    ws.title = title[:31] or "Sheet1"
    if isinstance(rows, dict):
        rows = [["key","value"]] + [[k, str(v)] for k,v in rows.items()]
    elif isinstance(rows, list) and rows and isinstance(rows[0], dict):
        headers = list(rows[0].keys())
        ws.append(headers)
        for r in rows:
            ws.append([r.get(h, "") for h in headers])
    else:
        for r in rows if isinstance(rows, list) else []:
            ws.append(r if isinstance(r, list) else [str(r)])
    buf = io.BytesIO()
    wb.save(buf)
    path = f"exports/{int(time.time())}-{_job_id()}.xlsx"
    return storage.save_bytes(path, buf.getvalue())

def export_md(title: str, content: str | Dict[str, Any]) -> str:
    if isinstance(content, dict):
        md_text = f"# {title}\n\n```json\n{json.dumps(content, indent=2)}\n```\n"
    else:
        md_text = f"# {title}\n\n{content}\n"
    path = f"exports/{int(time.time())}-{_job_id()}.md"
    return storage.save_text(path, md_text)
