import os, json
from pathlib import Path
from typing import Optional
from google.cloud import storage as gcs  # optional
from google.api_core.exceptions import NotFound

DATA_DIR = Path(os.getenv("DATA_DIR", "/app/data")).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)

GCS_BUCKET = os.getenv("GCS_BUCKET", "")
GCS_LOCATION = os.getenv("GCS_LOCATION", "US")

def _gcs_client() -> Optional[gcs.Client]:
    if not GCS_BUCKET:
        return None
    return gcs.Client()

def save_bytes(rel_path: str, data: bytes) -> str:
    if _gcs_client():
        bucket = _gcs_client().bucket(GCS_BUCKET)
        blob = bucket.blob(rel_path)
        blob.upload_from_string(data)
        return f"gs://{GCS_BUCKET}/{rel_path}"
    path = DATA_DIR / rel_path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return str(path)

def save_text(rel_path: str, text: str) -> str:
    return save_bytes(rel_path, text.encode('utf-8'))

def read_bytes(rel_path: str) -> bytes:
    if _gcs_client():
        bucket = _gcs_client().bucket(GCS_BUCKET)
        blob = bucket.blob(rel_path)
        try:
            return blob.download_as_bytes()
        except NotFound:
            raise FileNotFoundError(rel_path)
    path = DATA_DIR / rel_path
    return path.read_bytes()

def url_for(rel_path: str) -> str:
    if _gcs_client():
        return f"gs://{GCS_BUCKET}/{rel_path}"
    return str((DATA_DIR / rel_path).resolve())
