import math, os, time
from pathlib import Path
from typing import Tuple
import requests
from cachetools import LRUCache
from tenacity import retry, wait_fixed, stop_after_attempt

CACHE_DIR = Path(os.getenv("TILE_CACHE_DIR", "/app/data/tiles"))
CACHE_DIR.mkdir(parents=True, exist_ok=True)

MEM_CACHE = LRUCache(maxsize=256)

TILE_URL = os.getenv("TILE_URL", "https://tile.openstreetmap.org/{z}/{x}/{y}.png")
USER_AGENT = "RadarMindMap-TileCache/1.0"

def deg2num(lat_deg, lon_deg, zoom):
    lat_rad = math.radians(lat_deg)
    n = 2.0 ** zoom
    xtile = int((lon_deg + 180.0) / 360.0 * n)
    ytile = int((1.0 - math.log(math.tan(lat_rad) + 1 / math.cos(lat_rad)) / math.pi) / 2.0 * n)
    return xtile, ytile

def _file_for(z, x, y) -> Path:
    return CACHE_DIR / str(z) / str(x) / f"{y}.png"

@retry(wait=wait_fixed(1), stop=stop_after_attempt(3))
def fetch_tile(z: int, x: int, y: int) -> bytes:
    key = (z,x,y)
    if key in MEM_CACHE:
        return MEM_CACHE[key]
    path = _file_for(z,x,y)
    if path.exists():
        data = path.read_bytes()
        MEM_CACHE[key] = data
        return data
    url = TILE_URL.format(z=z,x=x,y=y)
    r = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=5)
    r.raise_for_status()
    data = r.content
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    MEM_CACHE[key] = data
    return data
