from pydantic import BaseModel, Field
from typing import Optional, List, Literal, Dict, Any

class ExportJob(BaseModel):
    id: str
    kind: Literal["docx","pdf","pptx","xlsx","md"]
    title: str
    content: str | Dict[str, Any]
    status: Literal["queued","running","done","error"] = "queued"
    error: Optional[str] = None
    output_path: Optional[str] = None

class TimesheetEntry(BaseModel):
    id: str
    user_id: str
    project: str
    start_ts: int
    end_ts: Optional[int] = None
    notes: Optional[str] = None
    location: Optional[Dict[str, float]] = None
    billable: bool = True
    rate_per_hour: Optional[float] = None
