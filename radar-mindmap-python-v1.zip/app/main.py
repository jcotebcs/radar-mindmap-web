from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from starlette.templating import Jinja2Templates
import os

from .routers import health, export, timesheet, whip

PORT = int(os.getenv("PORT", "8080"))
CORS_ORIGIN = os.getenv("CORS_ORIGIN", "*")

app = FastAPI(title="Radar MindMap Assistant (Python)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[CORS_ORIGIN] if CORS_ORIGIN != "*" else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix="")
app.include_router(export.router, prefix="/api/export")
app.include_router(timesheet.router, prefix="/api/timesheet")
app.include_router(whip.router, prefix="/whip")

# Static & templates for a minimal web UI (PWA-ready)
app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
